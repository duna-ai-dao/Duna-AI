export const log = (message: string) => {
  console.log(`[LOG]: ${message}`);
};
