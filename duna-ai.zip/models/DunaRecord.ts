export interface DunaRecord {
  id: string;
  name: string;
  description: string;
  parameters: Record<string, any>;
}
